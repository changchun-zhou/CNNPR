
------------------------------ Remark ----------------------------------------
We will be very happy to receive any kind of feedback regarding our tools and cores. 
We will also be willing to support any company intending to integrate our cores into their project.
For any questions / remarks / suggestions / bugs please contact info@provartec.com.
------------------------------------------------------------------------------

Opencores.org project - DMA AHB

This core is based on the Provartec PR201 IP - 'Generic High performance dual-core AHB DMA'

The original IP is a configurable, generic AHB DMA written in RobustVerilog.

This project contains two Verilog cores, one a 32-bit build and the other a 64-bit build.

To view the complete IP - http://www.provartec.com/ipproducts/57
